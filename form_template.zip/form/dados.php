<html>
<link rel="stylesheet" href="style2.css">
<meta charset="UTF-8">
        <link rel="stylesheet" href="style.css">
<?php

$nome1 = $_POST["nome1"];
$nome2 = $_POST["nome2"];
$nome3 = $_POST["nome3"];
$nome4 = $_POST["nome4"];
$nome5 = $_POST["nome5"];

$console1 = $_POST["console1"];
$console2 = $_POST["console2"];
$console3 = $_POST["console3"];
$console4 = $_POST["console4"];
$console5 = $_POST["console5"];


$cat1 = $_POST["cat1"];
$cat2 = $_POST["cat2"];
$cat3 = $_POST["cat3"];
$cat4 = $_POST["cat4"];
$cat5 = $_POST["cat5"];


$prod1 = $_POST["prod1"];
$prod2 = $_POST["prod2"];
$prod3 = $_POST["prod3"];
$prod4 = $_POST["prod4"];
$prod5 = $_POST["prod5"];


echo "
<table border=1.5vw solid black align=center>
    <caption> Tabela - Formulário de Jogos </caption>
    <tr>
        <th>Jogo</th>
        <th>Nome do Jogo</th>
        <th>Console</th>
        <th>Categoria</th>
        <th>Produtora</th>
    </tr>

    <tr>
        <td>1</td>
        <td>$nome1</td>
        <td>$console1</td>
        <td>$cat1</td>
        <td>$prod1</td>
    </tr>

    <tr>
        <td>2</td>
        <td>$nome2</td>
        <td>$console2</td>
        <td>$cat2</td>
        <td>$prod2</td>
    </tr>

    <tr>
        <td>3</td>
        <td>$nome3</td>
        <td>$console3</td>
        <td>$cat3</td>
        <td>$prod3</td>
    </tr>

    <tr>
        <td>4</td>
        <td>$nome4</td>
        <td>$console4</td>
        <td>$cat4</td>
        <td>$prod4</td>
    </tr>

    <tr>
        <td>5</td>
        <td>$nome5</td>
        <td>$console5</td>
        <td>$cat5</td>
        <td>$prod5</td>
    </tr>
    

</table>



";



?>  

<html>
